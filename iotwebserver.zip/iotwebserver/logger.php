<?php
header('Content-Type: text/plain');

$xml_file = 'data_log.xml';

if (!file_exists($xml_file)) {
    $xml = new SimpleXMLElement('<entries></entries>');
} else {
    $xml = simplexml_load_file($xml_file);
}

if (isset($_GET['light']) && isset($_GET['power']) && isset($_GET['collision']) && isset($_GET['threshold']) && isset($_GET['device_time'])) {
    $entry = $xml->addChild('entry');
    $entry->addChild('device_time', $_GET['device_time']);
    $entry->addChild('server_time', date('Y-m-d H:i:s'));
    $entry->addChild('light', $_GET['light']);
    $entry->addChild('power', $_GET['power']);
    $entry->addChild('collision', $_GET['collision']);
    $entry->addChild('threshold', $_GET['threshold']);
    $xml->asXML($xml_file);
    echo "ACK";
} else {
    echo "ERROR: Missing parameters.";
}
?>
