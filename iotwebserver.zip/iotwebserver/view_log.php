<?php
$xml_file = 'data_log.xml';

if (!file_exists($xml_file)) {
    echo "No logs found.";
    exit;
}

$xml = simplexml_load_file($xml_file);

$total_entries = count($xml->entry);
$threshold = (string)$xml->entry[count($xml->entry) - 1]->threshold;
$abnormal_power_states = 0;
$collision_events = [];
$power_events = [];

echo "<h1>Streetlight Monitor Log</h1>";
echo "<p>Total entries: $total_entries</p>";
echo "<p>Current Light Threshold: $threshold</p>";

echo "<table border='1' cellpadding='5'><tr><th>Device Time</th><th>Light</th><th>Power</th><th>Collision</th><th>Power State</th></tr>";

foreach ($xml->entry as $entry) {
    $device_time = (string)$entry->device_time;
    $light = (float)$entry->light;
    $power = (float)$entry->power;
    $collision = (string)$entry->collision;

    $power_state = "Normal";
    if ($power < 0) {
        $power_state = "Brownout";
        $abnormal_power_states++;
        $power_events[] = $device_time;
    } elseif ($power > 100) {
        $power_state = "Surge";
        $abnormal_power_states++;
        $power_events[] = $device_time;
    }

    if ($collision == "Collision") {
        $collision_events[] = $device_time;
    }

    echo "<tr><td>$device_time</td><td>$light</td><td>$power</td><td>$collision</td><td>$power_state</td></tr>";
}

echo "</table>";

echo "<h3>Abnormal Power State Timestamps:</h3><ul>";
foreach ($power_events as $time) {
    echo "<li>$time</li>";
}
echo "</ul>";

echo "<h3>Collision Event Timestamps:</h3><ul>";
foreach ($collision_events as $time) {
    echo "<li>$time</li>";
}
echo "</ul>";

echo "<p>Total abnormal power states: $abnormal_power_states</p>";
?>
