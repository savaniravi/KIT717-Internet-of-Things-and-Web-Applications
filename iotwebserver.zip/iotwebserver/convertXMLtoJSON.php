<?php
header('Content-Type: application/json');

$xml_file = 'data_log.xml';

if (!file_exists($xml_file)) {
    echo json_encode([]);
    exit;
}

$xml = simplexml_load_file($xml_file);

$data = [];

foreach ($xml->entry as $entry) {
    $data[] = [
        'device_time' => (string)$entry->device_time,
        'light' => (float)$entry->light,
        'power' => (float)$entry->power
    ];
}

echo json_encode($data);
?><?php

	header("Content-Type: application/json");


	$raw_xml = simplexml_load_file("tempData.xml");
	//var_dump($raw_xml);

	$new_json = json_encode($raw_xml);
	echo $new_json;

?>
