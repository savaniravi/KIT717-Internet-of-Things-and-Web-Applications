<?php
// Load XML data
$xml = simplexml_load_file('data_log.xml');

// Prepare arrays for Light and Power
$lightDataPoints = array();
$powerDataPoints = array();

foreach ($xml->entry as $entry) {
    $time = (string)$entry->device_time;
    $light = (float)$entry->light;
    $power = (float)$entry->power;

    $lightDataPoints[] = array("label" => $time, "y" => $light);
    $powerDataPoints[] = array("label" => $time, "y" => $power);
}
?>

<!DOCTYPE HTML>
<html>
<head>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
<title>Sensor Data Graph</title>
</head>
<body>
<h1>Streetlight Monitor Graph</h1>

<div id="chartContainer" style="height: 400px; width: 100%;"></div>

<script>
window.onload = function () {

var chart = new CanvasJS.Chart("chartContainer", {
    animationEnabled: true,
    title: {
        text: "Light and Power Readings"
    },
    axisX: {
        title: "Device Time",
        labelAngle: -50
    },
    axisY: {
        title: "Light (Humidity %)"
    },
    axisY2: {
        title: "Power (Temperature °C)",
        titleFontColor: "#C0504E",
        lineColor: "#C0504E",
        labelFontColor: "#C0504E",
        tickColor: "#C0504E"
    },
    toolTip: {
        shared: true
    },
    legend: {
        cursor: "pointer",
        itemclick: toggleDataSeries
    },
    data: [
    {
        type: "line",
        name: "Light (Humidity)",
        showInLegend: true,
        dataPoints: <?php echo json_encode($lightDataPoints, JSON_NUMERIC_CHECK); ?>
    },
    {
        type: "line",
        name: "Power (Temperature)",
        axisYType: "secondary",
        showInLegend: true,
        dataPoints: <?php echo json_encode($powerDataPoints, JSON_NUMERIC_CHECK); ?>
    }
    ]
});

chart.render();

function toggleDataSeries(e) {
    if (typeof(e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
        e.dataSeries.visible = false;
    } else {
        e.dataSeries.visible = true;
    }
    chart.render();
}

}
</script>

</body>
</html>
